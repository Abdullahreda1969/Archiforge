# 🏗️ Archiforge

**Build your future, folder by folder.**

Archiforge هي أداة سطر أوامر (CLI) قوية ومبتكرة مصممة لمساعدة المطورين على إنشاء مشاريعهم البرمجية في ثوانٍ. بدلاً من قضاء الوقت في إعداد الهيكل الأساسي، تقوم Archiforge بكل العمل الشاق عنك، من إنشاء الملفات إلى تهيئة Git وفتح المشروع في VS Code.

---

## ✨ المميزات الرئيسية (Features)

- 🚀 **قوالب جاهزة:** دعم لـ FastAPI, Node.js, React, و Python.
- 🐳 **جاهز للنشر:** إنشاء ملفات Dockerfile و Docker Compose تلقائياً.
- 🔗 **تكامل مع Git:** يقوم بتهيئة مستودع Git وعمل أول Commit تلقائياً.
- 💻 **تجربة مستخدم مذهلة:** واجهة ملونة، جداول احترافية، وشريط تقدم تفاعلي.
- ⚡ **تكامل مع VS Code:** يفتح مشروعك الجديد فوراً لتبدأ البرمجة.
- 🤖 **محرك التخيل (قريباً):** بناء مشاريع مخصصة بالكامل باستخدام Gemini AI.

---

## 🚀 كيفية التثبيت (Installation)

1. قم باستنساخ المستودع:

   ```bash
   git clone [https://github.com/Abdullahreda1969/archiforge.git](https://github.com/Abdullahreda1969/archiforge.git)
   cd archiforge
   قم بإنشاء بيئة معزولة وتثبيت المتطلبات:
   python -m venv venv
   source venv/Scripts/activate  # على Windows استخدم venv\Scripts\activate
   pip install -e .
   ```

🛠️ دليل الاستخدام (Usage)1. عرض القوالب المتاحةBasharchiforge list 2. إنشاء مشروع جديدBasharchiforge create --name MyGreatProject --lang fastapi 3. حذف مشروع (بأمان)Basharchiforge delete MyOldProject
📂 هيكل القوالب المدعومةالقالبالوصفالإضافاتFastAPIإطار عمل بايثون فائق السرعةDocker, Git, RequirementsNode.jsبيئة Express حديثةDocker, Package.jsonReactواجهة أمامية باستخدام ViteDocker (Nginx), Modern UIJavascriptمشاريع Vanilla Web سريعةHTML/CSS/JS🛡️ متطلبات التشغيلPython 3.10+Git (مثبت ومعد مسبقاً)VS Code (اختياري لفتح المشروع تلقائياً)🤝 المساهمة (Contribution)يسعدنا استقبال مساهماتكم! قم بعمل Fork للمشروع وابدأ في إضافة قوالبك الخاصة.تم تطويره بكل ❤️ بواسطة عبد الله رضا.

---
